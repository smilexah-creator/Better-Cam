package com.example.bettercam

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.net.Uri
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

object PhotoProcessor {

    fun process(file: File, style: Style, portrait: Boolean, blur: Float): Bitmap {
        var bmp = decode(file, if (portrait) 2400 else 4000)
        if (portrait) bmp = portraitBlur(bmp, blur)
        return applyStyle(bmp, style)
    }

    private fun decode(file: File, maxSide: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
        var bmp = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })!!
        val orient = ExifInterface(file.path).getAttributeInt(
            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        val m = Matrix()
        when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
        }
        val sc = maxSide.toFloat() / max(bmp.width, bmp.height)
        if (sc < 1f) m.postScale(sc, sc)
        if (!m.isIdentity) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        return bmp
    }

    fun applyStyle(src: Bitmap, style: Style): Bitmap {
        val cm = style.matrix() ?: return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(cm) }
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }

    /** Person cut-out via ML Kit, background blurred, soft feathered edge. */
    private fun portraitBlur(src: Bitmap, strength: Float): Bitmap {
        val w = src.width
        val h = src.height

        // 1) segmentation mask
        val segScale = 768f / max(w, h)
        val segBmp = if (segScale < 1f)
            Bitmap.createScaledBitmap(src, (w * segScale).toInt(), (h * segScale).toInt(), true) else src
        val opts = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build()
        val segmenter = Segmentation.getClient(opts)
        val mask = Tasks.await(segmenter.process(InputImage.fromBitmap(segBmp, 0)))
        segmenter.close()
        val mw = mask.width
        val mh = mask.height
        val buf = mask.buffer
        val px = IntArray(mw * mh)
        for (i in px.indices) {
            val conf = buf.getFloat()
            val t = ((conf - 0.35f) / 0.4f).coerceIn(0f, 1f)
            val a = t * t * (3f - 2f * t)
            px[i] = (a * 255f).toInt() shl 24
        }
        val maskBmp = Bitmap.createBitmap(mw, mh, Bitmap.Config.ARGB_8888)
        maskBmp.setPixels(px, 0, mw, 0, 0, mw, mh)

        // 2) blurred background (blur small copy, scale back up)
        val bs = 500f / max(w, h)
        val sw = (w * bs).toInt().coerceAtLeast(2)
        val sh = (h * bs).toInt().coerceAtLeast(2)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val pix = IntArray(sw * sh)
        small.getPixels(pix, 0, sw, 0, 0, sw, sh)
        val radius = (3 + strength * 14f).toInt()
        repeat(3) { boxBlur(pix, sw, sh, radius) }
        val blurredSmall = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        blurredSmall.setPixels(pix, 0, sw, 0, 0, sw, sh)
        val blurred = Bitmap.createScaledBitmap(blurredSmall, w, h, true)

        // 3) composite sharp subject over blurred background
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val oc = Canvas(out)
        oc.drawBitmap(blurred, 0f, 0f, null)
        val fg = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val fc = Canvas(fg)
        fc.drawBitmap(src, 0f, 0f, null)
        val p = Paint(Paint.FILTER_BITMAP_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
        fc.drawBitmap(maskBmp, null, Rect(0, 0, w, h), p)
        oc.drawBitmap(fg, 0f, 0f, null)
        return out
    }

    private fun boxBlur(pix: IntArray, w: Int, h: Int, r: Int) {
        if (r < 1) return
        val tmp = IntArray(pix.size)
        blurPass(pix, tmp, w, h, r, true)
        blurPass(tmp, pix, w, h, r, false)
    }

    private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val div = 2 * r + 1
        for (line in 0 until lines) {
            var ra = 0
            var ga = 0
            var ba = 0
            for (i in -r..r) {
                val k = i.coerceIn(0, len - 1)
                val p = src[if (horizontal) line * w + k else k * w + line]
                ra += (p shr 16) and 255; ga += (p shr 8) and 255; ba += p and 255
            }
            for (i in 0 until len) {
                val o = if (horizontal) line * w + i else i * w + line
                dst[o] = (0xFF shl 24) or ((ra / div) shl 16) or ((ga / div) shl 8) or (ba / div)
                val ai = (i + r + 1).coerceAtMost(len - 1)
                val si = (i - r).coerceAtLeast(0)
                val a = src[if (horizontal) line * w + ai else ai * w + line]
                val s = src[if (horizontal) line * w + si else si * w + line]
                ra += ((a shr 16) and 255) - ((s shr 16) and 255)
                ga += ((a shr 8) and 255) - ((s shr 8) and 255)
                ba += (a and 255) - (s and 255)
            }
        }
    }

    private fun values(): ContentValues = ContentValues().apply {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        put(MediaStore.Images.Media.DISPLAY_NAME, "IMG_$ts.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BetterCam")
    }

    fun saveBitmap(ctx: Context, bmp: Bitmap): Uri? {
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values()) ?: return null
        ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        return uri
    }

    fun copyToGallery(ctx: Context, file: File): Uri? {
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values()) ?: return null
        ctx.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
        return uri
    }
}
