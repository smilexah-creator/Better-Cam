package com.example.bettercam

import android.graphics.ColorMatrix

private fun sat(s: Float) = ColorMatrix().apply { setSaturation(s) }

private fun contrast(c: Float): ColorMatrix {
    val t = (-0.5f * c + 0.5f) * 255f
    return ColorMatrix(floatArrayOf(
        c, 0f, 0f, 0f, t,
        0f, c, 0f, 0f, t,
        0f, 0f, c, 0f, t,
        0f, 0f, 0f, 1f, 0f))
}

private fun tint(r: Float, g: Float, b: Float) = ColorMatrix(floatArrayOf(
    r, 0f, 0f, 0f, 0f,
    0f, g, 0f, 0f, 0f,
    0f, 0f, b, 0f, 0f,
    0f, 0f, 0f, 1f, 0f))

private fun combine(vararg m: ColorMatrix): ColorMatrix {
    val o = ColorMatrix()
    m.forEach { o.postConcat(it) }
    return o
}

enum class Style(val label: String) {
    NATURAL("Natural"), VIBRANT("Vibrant"), WARM("Warm"), COOL("Cool"),
    CINEMATIC("Cinematic"), DRAMATIC("Dramatic"), MONO("Mono");

    fun matrix(): ColorMatrix? = when (this) {
        NATURAL -> null
        VIBRANT -> combine(contrast(1.08f), sat(1.35f))
        WARM -> combine(tint(1.07f, 1.0f, 0.92f), sat(1.12f))
        COOL -> combine(tint(0.94f, 1.0f, 1.07f), sat(1.05f))
        CINEMATIC -> combine(contrast(1.15f), sat(0.88f), tint(0.97f, 1.0f, 1.05f))
        DRAMATIC -> combine(contrast(1.3f), sat(1.2f))
        MONO -> combine(sat(0f), contrast(1.2f))
    }
}
