package com.example.bettercam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

enum class Mode { PHOTO, PORTRAIT, VIDEO }

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var focusRing: View
    private lateinit var countdown: TextView
    private lateinit var grid: View
    private lateinit var evBar: SeekBar
    private lateinit var depthBar: SeekBar
    private lateinit var portraitLabel: TextView
    private lateinit var thumb: ImageView
    private lateinit var shutterInner: View
    private lateinit var tabs: Map<Mode, TextView>
    private lateinit var flashBtn: TextView
    private lateinit var timerBtn: TextView
    private lateinit var extBtn: TextView
    private lateinit var styleBtn: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val mainExec by lazy { ContextCompat.getMainExecutor(this) }

    private var cameraProvider: ProcessCameraProvider? = null
    private var extensionsManager: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null

    private var lens = CameraSelector.LENS_FACING_BACK
    private var mode = Mode.PHOTO
    private var flashMode = ImageCapture.FLASH_MODE_OFF
    private var torchOn = false
    private var timerSec = 0
    private var extIdx = 0
    private var style = Style.NATURAL
    private var evMin = 0
    private var lastUri: Uri? = null

    private val extModes = listOf(
        ExtensionMode.NONE to "Std",
        ExtensionMode.HDR to "HDR",
        ExtensionMode.NIGHT to "Night",
        ExtensionMode.AUTO to "Auto",
        ExtensionMode.FACE_RETOUCH to "Beauty"
    )

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { res ->
        if (res[Manifest.permission.CAMERA] == true) startCamera()
        else toast("Camera permission is required")
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        focusRing = findViewById(R.id.focusRing)
        countdown = findViewById(R.id.countdown)
        grid = findViewById(R.id.grid)
        evBar = findViewById(R.id.evBar)
        depthBar = findViewById(R.id.depthBar)
        portraitLabel = findViewById(R.id.portraitLabel)
        thumb = findViewById(R.id.thumb)
        shutterInner = findViewById(R.id.shutterInner)
        flashBtn = findViewById(R.id.flashBtn)
        timerBtn = findViewById(R.id.timerBtn)
        extBtn = findViewById(R.id.extBtn)
        styleBtn = findViewById(R.id.styleBtn)
        tabs = mapOf(
            Mode.PHOTO to findViewById(R.id.tabPhoto),
            Mode.PORTRAIT to findViewById(R.id.tabPortrait),
            Mode.VIDEO to findViewById(R.id.tabVideo)
        )

        tabs.forEach { (m, v) -> v.setOnClickListener { setMode(m) } }
        findViewById<View>(R.id.shutter).setOnClickListener { onShutter() }
        findViewById<View>(R.id.flipBtn).setOnClickListener {
            lens = if (lens == CameraSelector.LENS_FACING_BACK)
                CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            bindCamera()
        }
        flashBtn.setOnClickListener { cycleFlash() }
        timerBtn.setOnClickListener {
            timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
            timerBtn.text = if (timerSec == 0) "⏱ Off" else "⏱ ${timerSec}s"
        }
        findViewById<View>(R.id.gridBtn).setOnClickListener {
            grid.visibility = if (grid.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        extBtn.setOnClickListener { cycleExtension() }
        styleBtn.setOnClickListener {
            val all = Style.values()
            style = all[(style.ordinal + 1) % all.size]
            styleBtn.text = "🎨 ${style.label}"
            applyPreviewStyle()
        }
        thumb.setOnClickListener {
            val u = lastUri ?: return@setOnClickListener
            startActivity(Intent(Intent.ACTION_VIEW)
                .setDataAndType(u, contentResolver.getType(u))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }

        mapOf(R.id.z05 to 0.5f, R.id.z1 to 1f, R.id.z2 to 2f, R.id.z5 to 5f).forEach { (id, r) ->
            findViewById<View>(id).setOnClickListener { setZoom(r) }
        }

        depthBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) = updatePortraitLabel()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        evBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                camera?.cameraControl?.setExposureCompensationIndex(p + evMin)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val z = cam.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                cam.cameraControl.setZoomRatio(z * d.scaleFactor)
                return true
            }
        })
        val tap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean { focusAt(e.x, e.y); return true }
        })
        previewView.setOnTouchListener { _, ev -> scale.onTouchEvent(ev); tap.onTouchEvent(ev); true }

        updateTabs()
        permLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val provider = f.get()
            cameraProvider = provider
            val ef = ExtensionsManager.getInstanceAsync(this, provider)
            ef.addListener({
                extensionsManager = ef.get()
                bindCamera()
            }, mainExec)
        }, mainExec)
    }

    private fun bindCamera() {
        val provider = cameraProvider ?: return
        provider.unbindAll()
        var selector = CameraSelector.Builder().requireLensFacing(lens).build()
        val extMode = if (mode == Mode.PHOTO) extModes[extIdx].first else ExtensionMode.NONE
        val em = extensionsManager
        if (extMode != ExtensionMode.NONE && em != null && em.isExtensionAvailable(selector, extMode)) {
            selector = em.getExtensionEnabledCameraSelector(selector, extMode)
        }
        val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
        try {
            if (mode == Mode.VIDEO) {
                val recorder = Recorder.Builder().setQualitySelector(
                    QualitySelector.fromOrderedList(
                        listOf(Quality.UHD, Quality.FHD, Quality.HD),
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
                ).build()
                videoCapture = VideoCapture.Builder(recorder).setVideoStabilizationEnabled(true).build()
                imageCapture = null
                camera = provider.bindToLifecycle(this, selector, preview, videoCapture!!)
            } else {
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setFlashMode(flashMode).build()
                videoCapture = null
                camera = provider.bindToLifecycle(this, selector, preview, imageCapture!!)
            }
        } catch (e: Exception) {
            toast("Could not start camera: ${e.message}")
            camera = null
            return
        }
        camera?.let { cam ->
            val st = cam.cameraInfo.exposureState
            val range = st.exposureCompensationRange
            if (!st.isExposureCompensationSupported) {
                evBar.visibility = View.GONE
            } else {
                evBar.visibility = View.VISIBLE
                evMin = range.lower
                evBar.max = range.upper - range.lower
                evBar.progress = -range.lower
            }
        }
        applyPreviewStyle()
    }

    private fun setMode(m: Mode) {
        if (recording != null) return
        mode = m
        updateTabs()
        bindCamera()
    }

    private fun updateTabs() {
        tabs.forEach { (m, v) -> v.setTextColor(if (m == mode) 0xFFFFD60A.toInt() else 0xFFFFFFFF.toInt()) }
        val portrait = mode == Mode.PORTRAIT
        portraitLabel.visibility = if (portrait) View.VISIBLE else View.GONE
        depthBar.visibility = if (portrait) View.VISIBLE else View.GONE
        extBtn.visibility = if (mode == Mode.PHOTO) View.VISIBLE else View.INVISIBLE
        styleBtn.visibility = if (mode == Mode.VIDEO) View.INVISIBLE else View.VISIBLE
        flashBtn.text = if (mode == Mode.VIDEO) (if (torchOn) "🔦 On" else "🔦 Off") else flashLabel()
        updatePortraitLabel()
    }

    private fun updatePortraitLabel() {
        val blur = depthBar.progress / 100f
        val f = 16f - blur * 14.6f
        portraitLabel.text = "PORTRAIT  ƒ" + String.format(Locale.US, "%.1f", f)
    }

    private fun flashLabel() = when (flashMode) {
        ImageCapture.FLASH_MODE_AUTO -> "⚡ Auto"
        ImageCapture.FLASH_MODE_ON -> "⚡ On"
        else -> "⚡ Off"
    }

    private fun cycleFlash() {
        if (mode == Mode.VIDEO) {
            torchOn = !torchOn
            camera?.cameraControl?.enableTorch(torchOn)
        } else {
            flashMode = when (flashMode) {
                ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                else -> ImageCapture.FLASH_MODE_OFF
            }
            imageCapture?.flashMode = flashMode
        }
        updateTabs()
    }

    private fun cycleExtension() {
        val em = extensionsManager
        val sel = CameraSelector.Builder().requireLensFacing(lens).build()
        for (i in 1..extModes.size) {
            val c = (extIdx + i) % extModes.size
            if (c == 0 || em?.isExtensionAvailable(sel, extModes[c].first) == true) {
                extIdx = c
                break
            }
        }
        extBtn.text = "✨ ${extModes[extIdx].second}"
        bindCamera()
    }

    private fun applyPreviewStyle() {
        val cm = if (mode == Mode.VIDEO) null else style.matrix()
        val p = Paint()
        if (cm != null) p.colorFilter = ColorMatrixColorFilter(cm)
        previewView.setLayerType(View.LAYER_TYPE_HARDWARE, p)
    }

    private fun setZoom(r: Float) {
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value ?: return
        cam.cameraControl.setZoomRatio(r.coerceIn(zs.minZoomRatio, zs.maxZoomRatio))
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        cam.cameraControl.startFocusAndMetering(
            FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                .setAutoCancelDuration(4, TimeUnit.SECONDS).build())
        focusRing.animate().cancel()
        focusRing.x = x - focusRing.width / 2f
        focusRing.y = y - focusRing.height / 2f
        focusRing.visibility = View.VISIBLE
        focusRing.alpha = 1f
        focusRing.scaleX = 1.4f
        focusRing.scaleY = 1.4f
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            focusRing.animate().alpha(0f).setStartDelay(800).setDuration(300)
                .withEndAction { focusRing.visibility = View.GONE }.start()
        }.start()
    }

    private fun onShutter() {
        if (mode == Mode.VIDEO) toggleRecording() else runTimer { takePhoto() }
    }

    private fun runTimer(then: () -> Unit) {
        if (timerSec == 0) { then(); return }
        var left = timerSec
        countdown.visibility = View.VISIBLE
        val r = object : Runnable {
            override fun run() {
                if (left > 0) {
                    countdown.text = "$left"
                    left--
                    handler.postDelayed(this, 1000)
                } else {
                    countdown.visibility = View.GONE
                    then()
                }
            }
        }
        r.run()
    }

    private fun takePhoto() {
        val ic = imageCapture ?: return
        val tmp = File.createTempFile("cap", ".jpg", cacheDir)
        previewView.alpha = 0.3f
        previewView.animate().alpha(1f).setDuration(150).start()
        val portrait = mode == Mode.PORTRAIT
        val st = style
        val blur = depthBar.progress / 100f
        ic.takePicture(
            ImageCapture.OutputFileOptions.Builder(tmp).build(), mainExec,
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    worker.execute {
                        try {
                            val uri = if (!portrait && st == Style.NATURAL) {
                                PhotoProcessor.copyToGallery(this@MainActivity, tmp)
                            } else {
                                PhotoProcessor.saveBitmap(this@MainActivity,
                                    PhotoProcessor.process(tmp, st, portrait, blur))
                            }
                            runOnUiThread { lastUri = uri; refreshThumb(uri) }
                        } catch (e: Exception) {
                            runOnUiThread { toast("Processing failed: ${e.message}") }
                        } finally {
                            tmp.delete()
                        }
                    }
                }
                override fun onError(exc: ImageCaptureException) {
                    toast("Capture failed: ${exc.message}")
                }
            })
    }

    @SuppressLint("MissingPermission")
    private fun toggleRecording() {
        val vc = videoCapture ?: return
        val cur = recording
        if (cur != null) { cur.stop(); recording = null; return }
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VID_$ts")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/BetterCam")
        }
        val opts = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pending = vc.output.prepareRecording(this, opts)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED) pending = pending.withAudioEnabled()
        recording = pending.start(mainExec) { ev ->
            when (ev) {
                is VideoRecordEvent.Start -> {
                    shutterInner.setBackgroundResource(R.drawable.shutter_rec)
                    shutterInner.scaleX = 0.6f; shutterInner.scaleY = 0.6f
                }
                is VideoRecordEvent.Status -> {
                    val s = ev.recordingStats.recordedDurationNanos / 1_000_000_000L
                    countdown.visibility = View.GONE
                    portraitLabel.visibility = View.VISIBLE
                    portraitLabel.text = String.format(Locale.US, "● %02d:%02d", s / 60, s % 60)
                }
                is VideoRecordEvent.Finalize -> {
                    shutterInner.setBackgroundResource(R.drawable.shutter_inner)
                    shutterInner.scaleX = 1f; shutterInner.scaleY = 1f
                    portraitLabel.visibility = View.GONE
                    recording = null
                    if (!ev.hasError()) {
                        lastUri = ev.outputResults.outputUri
                        refreshThumb(lastUri)
                    } else toast("Recording error ${ev.error}")
                }
                else -> {}
            }
        }
    }

    private fun refreshThumb(uri: Uri?) {
        uri ?: return
        worker.execute {
            try {
                val b = contentResolver.loadThumbnail(uri, Size(160, 160), null)
                runOnUiThread { thumb.setImageBitmap(b) }
            } catch (e: Exception) { }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
