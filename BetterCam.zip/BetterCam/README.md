# BetterCam
Personal Android camera app (CameraX + ML Kit). Not for publishing.

Features: Photo / Portrait / Video modes, software portrait blur with adjustable ƒ-stop,
tap-to-focus, pinch zoom + .5/1/2/5x chips, exposure slider, HDR/Night/Auto/Beauty
(device extensions, if your phone supports them), 7 color styles with live preview,
timer, grid, flash/torch, front/back flip, 4K video with stabilization.

## Build with GitHub (private repo)
1. Create a **Private** repo on GitHub, upload all these files (keep the .github folder), push to `main`.
2. Open the repo → Actions → "Build APK" → wait ~5 min.
3. Open the finished run → Artifacts → download BetterCam-APK → unzip → install app-debug.apk on your phone.
